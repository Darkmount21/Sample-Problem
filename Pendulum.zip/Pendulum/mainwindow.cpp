#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtMath>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{

    length = ((qPow(4,2))*9.8)/(4*qPow(3.142,2));
    ui->textBrowser->setText("L =" + QString::number(length) + " m");

    omega = (2*3.142)/4;
    ui->textBrowser->append("ω =" + QString::number(omega) + " rad/s");

        amplitude = 40/omega;
    ui->textBrowser->append("a =" + QString::number(amplitude) + " cm");
}


void MainWindow::on_pushButton_2_clicked()
{
    QMessageBox msgBox;
    msgBox.setTextFormat(Qt::RichText); // this does the magic trick and allows you to click the link
    msgBox.setText("The function written in mainwindow.h is to determine the name of the variables."
                   "<br/>The function written in mainwindow.cpp in line 20 is to calculate the Length."
                   "<br/>To calculate the length, we rearrange Period formula so that Length can be found"
                   "<br/>The function written in mainwindow.cpp in line 25 is to calculate the omega by using the formula 2π / T or period."
                   "<br/>The function written in mainwindow.cpp in line 30 is to calculate the amplitude by using the formula Vmax / ω."
                   "<br/> The QString functions is to display the calculated results on the textbrowser."

                   );
    msgBox.exec();
}

